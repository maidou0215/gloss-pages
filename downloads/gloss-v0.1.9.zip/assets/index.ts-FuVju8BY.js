import{u as d,d as W,R as v,k as E}from"./hooks.module-DJQNu05E.js";import{g as X,a as N,S as q,l as S,d as j}from"./update-checker-BCx-B3Io.js";function D(e){let t=e.trim();return t=t.replace(/^[\s "'()[\]{}「」『』“”‘’`]+/,""),t=t.replace(/[\s "'()[\]{}「」『』“”‘’`.,;:!?。，；：！？]+$/,""),t}function O(e){if(!e)return!1;const t=e.trim();return!(t.length===0||t.length>200||/[\n\r]/.test(e))}const M=30,V=/[。？！.?!]/;function H(e){return e.length>M?{ok:!1,reason:`选区过长（${e.length} 字），请选 ${M} 字以内的单个术语`}:V.test(e)?{ok:!1,reason:"选区像是一句话，请选其中具体的术语"}:{ok:!0}}function Q(e){let t=null,o=!1;function n(){const l=window.getSelection();if(!l||l.isCollapsed||l.rangeCount===0){e(null);return}const u=l.toString(),g=D(u);if(!O(g)){e(null);return}const I=l.getRangeAt(0),f=I.getBoundingClientRect(),w=I.commonAncestorContainer,K=w.nodeType===Node.ELEMENT_NODE?w:w.parentElement;e({term:g,rect:{top:f.top,left:f.left,bottom:f.bottom,right:f.right},anchorEl:K})}function r(l){t&&window.clearTimeout(t),t=window.setTimeout(()=>{o||n()},l)}function i(){o=!0,t&&(window.clearTimeout(t),t=null)}function a(){o=!1,r(80)}function s(){if(o){const l=window.getSelection();(!l||l.isCollapsed)&&e(null);return}r(300)}return document.addEventListener("mousedown",i),document.addEventListener("mouseup",a),document.addEventListener("selectionchange",s),()=>{document.removeEventListener("mousedown",i),document.removeEventListener("mouseup",a),document.removeEventListener("selectionchange",s),t&&window.clearTimeout(t)}}const Z={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"};function ee(e){return e.replace(/[&<>"']/g,t=>Z[t])}const L="",R="";function P(e){const t=[];return e=e.replace(/`([^`\n]+)`/g,(o,n)=>{const r=t.push(`<code>${n}</code>`)-1;return`${L}${r}${R}`}),e=e.replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>"),e=e.replace(/\[([^\]\n]+)\]\(((?:https?|mailto):[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'),e=e.replace(/(^|[\s>(])\*([^\s*][^*\n]*?)\*(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(/(^|[\s>(])_([^\s_][^_\n]*?)_(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(new RegExp(`${L}(\\d+)${R}`,"g"),(o,n)=>t[Number(n)]??""),e}function te(e){if(!e)return"";const o=ee(e).split(`
`),n=[];let r=[];const i=()=>{r.length!==0&&(n.push({kind:"p",lines:r}),r=[])};for(const s of o){const l=s.match(/^\s*[-*+]\s+(.+)$/)||s.match(/^\s*\d+\.\s+(.+)$/);if(l){i();const u=n[n.length-1];(u==null?void 0:u.kind)==="ul"?u.items.push(l[1]):n.push({kind:"ul",items:[l[1]]})}else s.trim()===""?i():r.push(s)}i();const a=[];for(const s of n)if(s.kind==="ul"){a.push("<ul>");for(const l of s.items)a.push(`<li>${P(l)}</li>`);a.push("</ul>")}else a.push(`<p>${s.lines.map(P).join("<br>")}</p>`);return a.join("")}function oe({state:e,onClose:t,onRetry:o,updateInfo:n,onDismissUpdate:r}){if(e.kind==="loading")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:e.term}),d("div",{class:"gloss-loading",children:["查询中",d("span",{class:"gloss-dots"})]}),d(y,{info:n,onDismiss:r})]});const i=e.result;if(i.kind==="ai")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-ai",children:"AI"}),i.term,o&&d(U,{onRetry:o})]}),d("div",{class:"gloss-md",dangerouslySetInnerHTML:{__html:te(i.text)}}),d("div",{class:"gloss-src",children:["基于：",i.basedOn.join(", ")]}),d(y,{info:n,onDismiss:r})]});const a=i.code==="TERM_REJECTED"?void 0:o;return d(re,{err:i,onRetry:a,updateInfo:n,onDismissUpdate:r})}function y({info:e,onDismiss:t}){const[o,n]=W(!1);return!e||o?null:d("div",{class:"gloss-update-tip",children:[d("a",{class:"gloss-update-tip-link",href:e.url,target:"_blank",rel:"noopener noreferrer",title:e.notes?`v${e.latest}：${e.notes}`:`v${e.latest} 可用`,onMouseDown:r=>r.stopPropagation(),onClick:r=>r.stopPropagation(),children:[d("span",{class:"gloss-update-tip-dot",children:"●"}),"Gloss v",e.latest," 可用"]}),d("button",{class:"gloss-update-tip-close",title:"忽略此版本（下一版再提示）",onMouseDown:r=>r.stopPropagation(),onClick:r=>{r.stopPropagation(),n(!0),t==null||t(e.latest)},children:"✕"})]})}function U({onRetry:e}){return d("button",{class:"gloss-retry",title:"重新查询（绕过缓存）",onClick:t=>{t.stopPropagation(),e()},onMouseDown:t=>t.stopPropagation(),children:"⟳"})}function ne(e){switch(e.code){case"AI_NOT_CONFIGURED":return{title:"未配置 AI",body:e.message,hint:"右键扩展图标 → 选项 → 启用 AI 并填入 API Key"};case"RATE_LIMITED":{const t=e.resetEpochSec?Math.max(0,e.resetEpochSec-Math.floor(Date.now()/1e3)):null;return{title:"调用频率超限",body:e.message,hint:t?`约 ${t}s 后自动恢复`:"稍后再试"}}case"AI_FAILED":return{title:"AI 调用失败",body:e.message,hint:"检查 Base URL / Model / Key 是否正确，或查看 service worker 控制台日志"};case"TERM_REJECTED":return{title:"选区不适合查询",body:e.message,hint:"重新选个具体术语再试（不要选整句或一长段）"};case"UNKNOWN":default:return{title:"未知错误",body:e.message}}}function re({err:e,onRetry:t,updateInfo:o,onDismissUpdate:n}){const r=ne(e);return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-error",children:"错误"}),e.term,t&&d(U,{onRetry:t})]}),d("div",{class:"gloss-err-title",children:r.title}),d("div",{class:"gloss-err-body",children:r.body}),r.hint&&d("div",{class:"gloss-hint",children:r.hint}),d(y,{info:o,onDismiss:n})]})}const se=`
.gloss-tooltip {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: #ffffff; color: #1f2328; border: 1px solid #d0d7de;
  border-radius: 6px;
  padding: 10px 12px; font-size: 12px; line-height: 1.5;
  box-shadow: 0 6px 18px rgba(0,0,0,0.10);
  max-width: 320px;
  max-height: 60vh; overflow: auto;
  word-break: break-word; overflow-wrap: anywhere;
}
.gloss-icon {
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  width: 18px; height: 18px; border-radius: 9px;
  /* 跟工具栏图标主色 #2CC778 对齐（scripts/build-icon-16.py 取自 icon-48.png 主导绿） */
  background: #2CC778; color: #fff; font-size: 11px;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  user-select: none;
}
.gloss-header {
  font-weight: 700; margin-bottom: 6px; color: #1f2328;
  display: flex; align-items: center; gap: 4px;
}
.gloss-retry {
  margin-left: auto;
  background: transparent; border: none; cursor: pointer;
  color: #656d76; font-size: 14px; line-height: 1;
  padding: 2px 6px; border-radius: 4px;
  user-select: none;
}
.gloss-retry:hover { background: #f0f3f6; color: #1f2328; }
.gloss-retry:active { transform: rotate(180deg); transition: transform 0.3s; }
.gloss-tag {
  display: inline-block; padding: 1px 6px; border-radius: 3px;
  font-size: 10px; margin-right: 6px; font-weight: 600;
  vertical-align: middle; color: #fff;
  /* gloss-header 是 flex 容器，长 term 会触发收缩——
     tag 不加 flex-shrink:0 + white-space:nowrap 会让"错误"两字被压成竖排（一个字一行） */
  flex-shrink: 0;
  white-space: nowrap;
}
.gloss-tag-ai { background: #fb8500; }
.gloss-tag-error { background: #d73a49; }

/* Markdown 渲染样式 */
.gloss-md { font-size: 12px; }
.gloss-md p { margin: 0 0 6px 0; }
.gloss-md p:last-child { margin-bottom: 0; }
.gloss-md ul { margin: 4px 0; padding-left: 18px; }
.gloss-md li { margin: 2px 0; }
.gloss-md code {
  background: #f6f8fa; color: #cf222e; padding: 1px 4px;
  border-radius: 3px; font-family: ui-monospace, monospace;
  font-size: 11px;
}
.gloss-md strong { font-weight: 700; color: #1f2328; }
.gloss-md em { font-style: italic; color: #1f2328; }
.gloss-md a { color: #0969da; text-decoration: none; }
.gloss-md a:hover { text-decoration: underline; }

/* 加载/错误态 */
.gloss-loading { color: #656d76; }
.gloss-dots::after {
  content: '...'; display: inline-block;
  animation: gloss-dots 1.2s infinite steps(4);
  width: 1.2em; text-align: left;
}
@keyframes gloss-dots {
  0%, 25% { content: ''; }
  50%     { content: '.'; }
  75%     { content: '..'; }
  100%    { content: '...'; }
}
.gloss-err-title { color: #cf222e; font-weight: 600; margin-bottom: 4px; }
.gloss-err-body { color: #656d76; font-size: 11px; margin-bottom: 6px; }
.gloss-hint {
  color: #656d76; font-size: 10px;
  border-top: 1px solid #d0d7de; padding-top: 6px; margin-top: 4px;
}

.gloss-src {
  color: #656d76; font-size: 10px; margin-top: 8px;
  padding-top: 6px; border-top: 1px solid #d0d7de;
}
.gloss-src a { color: #0969da; text-decoration: none; }

/* 更新 tip：底部小字，可有可无；左边是跳转链接，右边是 ✕ 关闭 */
.gloss-update-tip {
  display: flex; align-items: center; gap: 4px;
  margin-top: 6px; padding-top: 6px;
  border-top: 1px dashed #d0d7de;
  font-size: 10px;
}
.gloss-update-tip-link {
  flex: 1;
  display: inline-flex; align-items: center; gap: 5px;
  color: #656d76; text-decoration: none;
  transition: color 0.12s;
}
.gloss-update-tip-link:hover { color: #0969da; }
.gloss-update-tip-dot {
  color: #2da44e; font-size: 6px; line-height: 1;
}
.gloss-update-tip-close {
  background: transparent; border: none; cursor: pointer;
  color: #8b949e; font-size: 11px; line-height: 1;
  padding: 1px 5px; border-radius: 3px;
  transition: background 0.12s, color 0.12s;
}
.gloss-update-tip-close:hover { background: #f0f3f6; color: #1f2328; }

/* 暗色：跟随【当前页面】背景亮度判定（content/index.ts detectPageTheme），
   不再用 prefers-color-scheme——系统 dark mode 下白底页面会被误判 */
.gloss-theme-dark .gloss-tooltip {
  background: #1a1a1a; color: #fff; border-color: #30363d;
  box-shadow: 0 6px 18px rgba(0,0,0,0.40);
}
.gloss-theme-dark .gloss-header { color: #fff; }
.gloss-theme-dark .gloss-md code { background: #21262d; color: #d2a8ff; }
.gloss-theme-dark .gloss-md strong { color: #fff; }
.gloss-theme-dark .gloss-md em { color: #c9d1d9; }
.gloss-theme-dark .gloss-md a { color: #79c0ff; }
.gloss-theme-dark .gloss-loading { color: #c9d1d9; }
.gloss-theme-dark .gloss-err-title { color: #ffb4ab; }
.gloss-theme-dark .gloss-err-body { color: #c9d1d9; }
.gloss-theme-dark .gloss-hint { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src a { color: #79c0ff; }
.gloss-theme-dark .gloss-retry { color: #8b949e; }
.gloss-theme-dark .gloss-retry:hover { background: #21262d; color: #fff; }
.gloss-theme-dark .gloss-update-tip { border-top-color: #30363d; }
.gloss-theme-dark .gloss-update-tip-link { color: #8b949e; }
.gloss-theme-dark .gloss-update-tip-link:hover { color: #79c0ff; }
.gloss-theme-dark .gloss-update-tip-dot { color: #56d364; }
.gloss-theme-dark .gloss-update-tip-close { color: #6e7681; }
.gloss-theme-dark .gloss-update-tip-close:hover { background: #21262d; color: #fff; }
`,_="gloss-occurrence",A="gloss-highlight-style",le=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT","CODE"]),$=500;function F(){const e=globalThis.CSS;return!e||!e.highlights||typeof globalThis.Highlight!="function"?null:e.highlights}function ie(){if(document.getElementById(A))return;const e=document.createElement("style");e.id=A,e.textContent=`::highlight(${_}) { background-color: rgba(255, 222, 89, 0.45); border-radius: 2px; }`,document.head.appendChild(e)}function ce(e){const t=F();if(!t)return 0;ie(),z();const o=e.toLowerCase();if(o.length<2)return 0;const n=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(s){const l=s.parentElement;return!l||le.has(l.tagName)||l.isContentEditable?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),r=[];let i;for(;i=n.nextNode();){const s=i.textContent??"";if(!s)continue;const l=s.toLowerCase();let u=0;for(;(u=l.indexOf(o,u))>=0;){const g=document.createRange();if(g.setStart(i,u),g.setEnd(i,u+o.length),r.push(g),u+=o.length,r.length>=$)break}if(r.length>=$)break}if(r.length===0)return 0;const a=globalThis.Highlight;return t.set(_,new a(...r)),r.length}function z(){const e=F();e&&e.delete(_)}const k=1e3;function ae(e,t){const n=t.toLowerCase().indexOf(e.toLowerCase());if(n<0)return t.slice(0,k*2);const r=Math.max(0,n-k),i=Math.min(t.length,n+e.length+k);return t.slice(r,i)}const C="gloss-host",de="gloss-icon",ue="lookup-stream",c=window.__gloss??(window.__gloss={tooltipShown:!1,inited:!1,prefetch:null,activeTerm:null,activeInfo:null,tipPos:null,theme:"auto",updateInfo:null});function ge(){let e=document.getElementById(C);if(e)return e.shadowRoot;e=document.createElement("div"),e.id=C,e.style.cssText="position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",document.documentElement.appendChild(e);const t=e.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=se,t.appendChild(o);const n=document.createElement("div");return n.id="gloss-root",t.appendChild(n),t}function b(){return ge().getElementById("gloss-root")}function p(){c.tooltipShown=!1,c.activeTerm=null,c.activeInfo=null,c.tipPos=null,z();const e=b();for(v(null,e);e.firstChild;)e.removeChild(e.firstChild)}const T=320,m=8,h=8;function pe(e){const t=window.innerWidth,o=window.innerHeight;let n=e.left;n+T+h>t&&(n=Math.max(h,t-T-h));const r=o-e.bottom-m-h,i=e.top-m-h,a=r<200&&i>r,s=a?e.top-m:e.bottom+m;return{left:n,top:s,flipUp:a}}function he(e){if(c.theme==="light"||c.theme==="dark")return c.theme;let t=e;for(;t;){const n=window.getComputedStyle(t).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);if(n&&(n[4]!==void 0?Number(n[4]):1)>=.5){const i=Number(n[1]),a=Number(n[2]),s=Number(n[3]);return .299*i+.587*a+.114*s<128?"dark":"light"}t=t.parentElement}return typeof window.matchMedia=="function"&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function fe(){var t;const e=["article","main",".markdown-body",'[role="main"]',"#content"];for(const o of e){const n=document.querySelector(o),r=n==null?void 0:n.innerText;if(r&&r.length>200)return r.slice(0,1e5)}return(((t=document.body)==null?void 0:t.innerText)??"").slice(0,1e5)}function B(e,t){const o={term:e,text:"",done:!1,result:null,listeners:new Set},n=()=>{for(const s of o.listeners)try{s()}catch(l){S.warn("listener 异常",l)}},r=s=>{o.done||(o.done=!0,o.result={kind:"error",term:e,code:"UNKNOWN",message:s},n())};let i;try{i=chrome.runtime.connect({name:ue})}catch(s){return r(s instanceof Error?s.message:String(s)),o}i.onMessage.addListener(s=>{s.type==="chunk"?(o.text+=s.text,n()):(o.done=!0,o.result=s.result,s.result.kind==="ai"&&!o.text&&(o.text=s.result.text),n())}),i.onDisconnect.addListener(()=>{var s;o.done||r(((s=chrome.runtime.lastError)==null?void 0:s.message)??"Port 断开")});const a={type:"lookup",term:e,pageText:ae(e,fe()),pageUrl:location.href,bypassCache:t==null?void 0:t.bypassCache};try{i.postMessage(a)}catch(s){r(s instanceof Error?s.message:String(s))}return o}function G(e){var t;return((t=c.prefetch)==null?void 0:t.term)===e||(c.prefetch=B(e)),c.prefetch}function me(e){const t=b(),o=e.rect.right+4,n=e.rect.top-4,r=H(e.term),i=r.ok?"点击查询":r.reason;v(E("div",{id:de,class:"gloss-icon",title:i,style:`position:absolute;left:${o}px;top:${n}px;`,onMouseEnter:()=>{r.ok&&G(e.term)},onClick:()=>J(e)},"G"),t)}function xe(e){j(e).catch(()=>{}),c.updateInfo=null}function x(e,t){var u;c.tooltipShown=!0,c.activeTerm=e.term,c.tipPos||(c.tipPos=pe(e.rect));const{left:o,top:n,flipUp:r}=c.tipPos,i=b(),a=r?"transform:translateY(-100%);":"",s=t.kind==="loading"?void 0:be,l=he(((u=c.activeInfo)==null?void 0:u.anchorEl)??null)==="dark"?"gloss-theme-dark":"gloss-theme-light";v(E("div",{class:l,style:`position:absolute;left:${o}px;top:${n}px;${a}width:max-content;max-width:${T}px;`},E(oe,{state:t,onClose:p,onRetry:s,updateInfo:c.updateInfo,onDismissUpdate:xe})),i)}function Y(e,t){c.activeInfo=e;let o=!0;const n=()=>{!o&&(!c.tooltipShown||c.activeTerm!==e.term)||(o=!1,t.done&&t.result?x(e,{kind:"result",result:t.result}):t.text?x(e,{kind:"result",result:{kind:"ai",term:e.term,text:t.text,basedOn:[location.href]}}):x(e,{kind:"loading",term:e.term}))};t.listeners.add(n),n()}function J(e){const t=H(e.term);if(!t.ok){c.activeInfo=e,x(e,{kind:"result",result:{kind:"error",code:"TERM_REJECTED",term:e.term,message:t.reason}});return}const o=G(e.term);Y(e,o);try{ce(e.term)}catch(n){S.warn("highlight 失败",n)}}function be(){const e=c.activeInfo;if(!e)return;c.prefetch&&(c.prefetch.listeners.clear(),c.prefetch=null);const t=B(e.term,{bypassCache:!0});c.prefetch=t,Y(e,t)}function we(){var l;const e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return;const t=e.toString(),o=D(t);if(!O(o))return;const n=e.getRangeAt(0),r=n.getBoundingClientRect(),i=n.commonAncestorContainer,a=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement,s={term:o,rect:{top:r.top,left:r.left,bottom:r.bottom,right:r.right},anchorEl:a};c.activeTerm!==o&&(c.tipPos=null,((l=c.prefetch)==null?void 0:l.term)!==o&&(c.prefetch=null)),J(s)}function ke(e){if(history.pushState.__gloss)return;let t=location.href;const o=()=>{location.href!==t&&(t=location.href,e())};window.addEventListener("popstate",o);const n=history.pushState.bind(history),r=history.replaceState.bind(history),i=function(...s){n(...s),o()},a=function(...s){r(...s),o()};i.__gloss=!0,a.__gloss=!0,history.pushState=i,history.replaceState=a}function Ee(){var n,r,i,a,s;if(c.inited)return;c.inited=!0,X().then(l=>{c.theme=l.theme}).catch(()=>{});const e=((i=(r=(n=chrome.runtime)==null?void 0:n.getManifest)==null?void 0:r.call(n))==null?void 0:i.version)??"0.0.0";N(e).then(l=>{c.updateInfo=l}).catch(()=>{}),(s=(a=chrome.storage)==null?void 0:a.onChanged)==null||s.addListener((l,u)=>{if(u==="local"){if(l.settings){const g=l.settings.newValue;g!=null&&g.theme&&(c.theme=g.theme)}l[q]&&N(e).then(g=>{c.updateInfo=g}).catch(()=>{})}}),Q(l=>{if(!c.tooltipShown){if(!l){p();return}c.prefetch&&c.prefetch.term!==l.term&&(c.prefetch=null),me(l)}}),document.addEventListener("keydown",l=>{l.key==="Escape"&&p()}),document.addEventListener("mousedown",l=>{const u=document.getElementById(C);u&&!u.contains(l.target)&&p()},{capture:!0});const t=300;let o=null;window.addEventListener("scroll",l=>{if(!b().firstChild){o=null;return}if(!(l.target===document||l.target===document.documentElement)){p(),o=null;return}o===null&&(o=window.scrollY),Math.abs(window.scrollY-o)>t&&(p(),o=null)},{capture:!0,passive:!0}),ke(()=>{S.debug("URL changed, unmount tooltip",location.href),p()}),chrome.runtime.onMessage.addListener(l=>{(l==null?void 0:l.type)==="trigger-lookup"&&we()})}Ee();
