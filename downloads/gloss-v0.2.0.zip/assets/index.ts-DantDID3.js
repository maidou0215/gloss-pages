import{u as d,d as q,R as S,k as y}from"./hooks.module-DJQNu05E.js";import{t as g,g as K,s as L,b as N,S as V,l as _,d as Q}from"./i18n-CLhuultJ.js";function D(e){let t=e.trim();return t=t.replace(/^[\s "'()[\]{}「」『』“”‘’`]+/,""),t=t.replace(/[\s "'()[\]{}「」『』“”‘’`.,;:!?。，；：！？]+$/,""),t}function U(e){if(!e)return!1;const t=e.trim();return!(t.length===0||t.length>200||/[\n\r]/.test(e))}const M=30,Z=/[。？！.?!]/;function F(e){return e.length>M?{ok:!1,reason:g("selectionTooLong",[String(e.length),String(M)])}:Z.test(e)?{ok:!1,reason:g("selectionSentence")}:{ok:!0}}function ee(e){let t=null,o=!1;function n(){const s=window.getSelection();if(!s||s.isCollapsed||s.rangeCount===0){e(null);return}const u=s.toString(),p=D(u);if(!U(p)){e(null);return}const R=s.getRangeAt(0),m=R.getBoundingClientRect(),k=R.commonAncestorContainer,X=k.nodeType===Node.ELEMENT_NODE?k:k.parentElement;e({term:p,rect:{top:m.top,left:m.left,bottom:m.bottom,right:m.right},anchorEl:X})}function r(s){t&&window.clearTimeout(t),t=window.setTimeout(()=>{o||n()},s)}function l(){o=!0,t&&(window.clearTimeout(t),t=null)}function a(){o=!1,r(80)}function i(){if(o){const s=window.getSelection();(!s||s.isCollapsed)&&e(null);return}r(300)}return document.addEventListener("mousedown",l),document.addEventListener("mouseup",a),document.addEventListener("selectionchange",i),()=>{document.removeEventListener("mousedown",l),document.removeEventListener("mouseup",a),document.removeEventListener("selectionchange",i),t&&window.clearTimeout(t)}}const te={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"};function oe(e){return e.replace(/[&<>"']/g,t=>te[t])}const P="",A="";function $(e){const t=[];return e=e.replace(/`([^`\n]+)`/g,(o,n)=>{const r=t.push(`<code>${n}</code>`)-1;return`${P}${r}${A}`}),e=e.replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>"),e=e.replace(/\[([^\]\n]+)\]\(((?:https?|mailto):[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'),e=e.replace(/(^|[\s>(])\*([^\s*][^*\n]*?)\*(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(/(^|[\s>(])_([^\s_][^_\n]*?)_(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(new RegExp(`${P}(\\d+)${A}`,"g"),(o,n)=>t[Number(n)]??""),e}function ne(e){if(!e)return"";const o=oe(e).split(`
`),n=[];let r=[];const l=()=>{r.length!==0&&(n.push({kind:"p",lines:r}),r=[])};for(const i of o){const s=i.match(/^\s*[-*+]\s+(.+)$/)||i.match(/^\s*\d+\.\s+(.+)$/);if(s){l();const u=n[n.length-1];(u==null?void 0:u.kind)==="ul"?u.items.push(s[1]):n.push({kind:"ul",items:[s[1]]})}else i.trim()===""?l():r.push(i)}l();const a=[];for(const i of n)if(i.kind==="ul"){a.push("<ul>");for(const s of i.items)a.push(`<li>${$(s)}</li>`);a.push("</ul>")}else a.push(`<p>${i.lines.map($).join("<br>")}</p>`);return a.join("")}function re({state:e,onClose:t,onRetry:o,updateInfo:n,onDismissUpdate:r}){if(e.kind==="loading")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:e.term}),d("div",{class:"gloss-loading",children:[g("tooltipLoading"),d("span",{class:"gloss-dots"})]}),d(T,{info:n,onDismiss:r})]});const l=e.result;if(l.kind==="ai")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-ai",children:"AI"}),l.term,o&&d(z,{onRetry:o})]}),d("div",{class:"gloss-md",dangerouslySetInnerHTML:{__html:ne(l.text)}}),d("div",{class:"gloss-src",children:[g("tooltipBasedOn"),l.basedOn.join(", ")]}),d(T,{info:n,onDismiss:r})]});const a=l.code==="TERM_REJECTED"?void 0:o;return d(ie,{err:l,onRetry:a,updateInfo:n,onDismissUpdate:r})}function T({info:e,onDismiss:t}){const[o,n]=q(!1);return!e||o?null:d("div",{class:"gloss-update-tip",children:[d("a",{class:"gloss-update-tip-link",href:e.url,target:"_blank",rel:"noopener noreferrer",title:e.notes?g("tooltipUpdateTitleWithNotes",[e.latest,e.notes]):g("tooltipUpdateTitleOnly",e.latest),onMouseDown:r=>r.stopPropagation(),onClick:r=>r.stopPropagation(),children:[d("span",{class:"gloss-update-tip-dot",children:"●"}),g("tooltipUpdateAvailable",e.latest)]}),d("button",{class:"gloss-update-tip-close",title:g("tooltipDismissUpdateTitle"),onMouseDown:r=>r.stopPropagation(),onClick:r=>{r.stopPropagation(),n(!0),t==null||t(e.latest)},children:"✕"})]})}function z({onRetry:e}){return d("button",{class:"gloss-retry",title:g("tooltipRetryTitle"),onClick:t=>{t.stopPropagation(),e()},onMouseDown:t=>t.stopPropagation(),children:"⟳"})}function se(e){switch(e.code){case"AI_NOT_CONFIGURED":return{title:g("errorNotConfiguredTitle"),body:e.message,hint:g("errorNotConfiguredHint")};case"RATE_LIMITED":{const t=e.resetEpochSec?Math.max(0,e.resetEpochSec-Math.floor(Date.now()/1e3)):null;return{title:g("errorRateLimitedTitle"),body:e.message,hint:t?g("errorRateLimitedHintSeconds",String(t)):g("errorRateLimitedHintRetry")}}case"AI_FAILED":return{title:g("errorAiFailedTitle"),body:e.message,hint:g("errorAiFailedHint")};case"TERM_REJECTED":return{title:g("errorTermRejectedTitle"),body:e.message,hint:g("errorTermRejectedHint")};case"UNKNOWN":default:return{title:g("errorUnknownTitle"),body:e.message}}}function ie({err:e,onRetry:t,updateInfo:o,onDismissUpdate:n}){const r=se(e);return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-error",children:g("tooltipErrorTag")}),e.term,t&&d(z,{onRetry:t})]}),d("div",{class:"gloss-err-title",children:r.title}),d("div",{class:"gloss-err-body",children:r.body}),r.hint&&d("div",{class:"gloss-hint",children:r.hint}),d(T,{info:o,onDismiss:n})]})}const le=`
.gloss-tooltip {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: #ffffff; color: #1f2328; border: 1px solid #d0d7de;
  border-radius: 6px;
  padding: 10px 12px; font-size: 12px; line-height: 1.5;
  box-shadow: 0 6px 18px rgba(0,0,0,0.10);
  max-width: 380px;
  max-height: 60vh; overflow: auto;
  word-break: break-word; overflow-wrap: anywhere;
}
.gloss-icon {
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  width: 18px; height: 18px; border-radius: 9px;
  /* 跟工具栏图标主色 #2CC778 对齐（scripts/build-icon-16.py 取自 icon-48.png 主导绿） */
  background: #2CC778; color: #fff; font-size: 11px;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  user-select: none;
}
.gloss-header {
  font-weight: 700; margin-bottom: 6px; color: #1f2328;
  display: flex; align-items: center; gap: 4px;
}
.gloss-retry {
  margin-left: auto;
  background: transparent; border: none; cursor: pointer;
  color: #656d76; font-size: 14px; line-height: 1;
  padding: 2px 6px; border-radius: 4px;
  user-select: none;
}
.gloss-retry:hover { background: #f0f3f6; color: #1f2328; }
.gloss-retry:active { transform: rotate(180deg); transition: transform 0.3s; }
.gloss-tag {
  display: inline-block; padding: 1px 6px; border-radius: 3px;
  font-size: 10px; margin-right: 6px; font-weight: 600;
  vertical-align: middle; color: #fff;
  /* gloss-header 是 flex 容器，长 term 会触发收缩——
     tag 不加 flex-shrink:0 + white-space:nowrap 会让"错误"两字被压成竖排（一个字一行） */
  flex-shrink: 0;
  white-space: nowrap;
}
.gloss-tag-ai { background: #fb8500; }
.gloss-tag-error { background: #d73a49; }

/* Markdown 渲染样式 */
.gloss-md { font-size: 12px; }
.gloss-md p { margin: 0 0 6px 0; }
.gloss-md p:last-child { margin-bottom: 0; }
.gloss-md ul { margin: 4px 0; padding-left: 18px; }
.gloss-md li { margin: 2px 0; }
.gloss-md code {
  background: #f6f8fa; color: #cf222e; padding: 1px 4px;
  border-radius: 3px; font-family: ui-monospace, monospace;
  font-size: 11px;
}
.gloss-md strong { font-weight: 700; color: #1f2328; }
.gloss-md em { font-style: italic; color: #1f2328; }
.gloss-md a { color: #0969da; text-decoration: none; }
.gloss-md a:hover { text-decoration: underline; }

/* 加载/错误态 */
.gloss-loading { color: #656d76; }
.gloss-dots::after {
  content: '...'; display: inline-block;
  animation: gloss-dots 1.2s infinite steps(4);
  width: 1.2em; text-align: left;
}
@keyframes gloss-dots {
  0%, 25% { content: ''; }
  50%     { content: '.'; }
  75%     { content: '..'; }
  100%    { content: '...'; }
}
.gloss-err-title { color: #cf222e; font-weight: 600; margin-bottom: 4px; }
.gloss-err-body { color: #656d76; font-size: 11px; margin-bottom: 6px; }
.gloss-hint {
  color: #656d76; font-size: 11px;
  border-top: 1px solid #d0d7de; padding-top: 6px; margin-top: 4px;
}

.gloss-src {
  color: #656d76; font-size: 10px; margin-top: 8px;
  padding-top: 6px; border-top: 1px solid #d0d7de;
}
.gloss-src a { color: #0969da; text-decoration: none; }

/* 更新 tip：底部小字，可有可无；左边是跳转链接，右边是 ✕ 关闭 */
.gloss-update-tip {
  display: flex; align-items: center; gap: 4px;
  margin-top: 6px; padding-top: 6px;
  border-top: 1px dashed #d0d7de;
  font-size: 10px;
}
.gloss-update-tip-link {
  flex: 1;
  display: inline-flex; align-items: center; gap: 5px;
  color: #656d76; text-decoration: none;
  transition: color 0.12s;
}
.gloss-update-tip-link:hover { color: #0969da; }
.gloss-update-tip-dot {
  color: #2da44e; font-size: 6px; line-height: 1;
}
.gloss-update-tip-close {
  background: transparent; border: none; cursor: pointer;
  color: #8b949e; font-size: 11px; line-height: 1;
  padding: 1px 5px; border-radius: 3px;
  transition: background 0.12s, color 0.12s;
}
.gloss-update-tip-close:hover { background: #f0f3f6; color: #1f2328; }

/* 暗色：跟随【当前页面】背景亮度判定（content/index.ts detectPageTheme），
   不再用 prefers-color-scheme——系统 dark mode 下白底页面会被误判 */
.gloss-theme-dark .gloss-tooltip {
  background: #1a1a1a; color: #fff; border-color: #30363d;
  box-shadow: 0 6px 18px rgba(0,0,0,0.40);
}
.gloss-theme-dark .gloss-header { color: #fff; }
.gloss-theme-dark .gloss-md code { background: #21262d; color: #d2a8ff; }
.gloss-theme-dark .gloss-md strong { color: #fff; }
.gloss-theme-dark .gloss-md em { color: #c9d1d9; }
.gloss-theme-dark .gloss-md a { color: #79c0ff; }
.gloss-theme-dark .gloss-loading { color: #c9d1d9; }
.gloss-theme-dark .gloss-err-title { color: #ffb4ab; }
.gloss-theme-dark .gloss-err-body { color: #c9d1d9; }
.gloss-theme-dark .gloss-hint { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src a { color: #79c0ff; }
.gloss-theme-dark .gloss-retry { color: #8b949e; }
.gloss-theme-dark .gloss-retry:hover { background: #21262d; color: #fff; }
.gloss-theme-dark .gloss-update-tip { border-top-color: #30363d; }
.gloss-theme-dark .gloss-update-tip-link { color: #8b949e; }
.gloss-theme-dark .gloss-update-tip-link:hover { color: #79c0ff; }
.gloss-theme-dark .gloss-update-tip-dot { color: #56d364; }
.gloss-theme-dark .gloss-update-tip-close { color: #6e7681; }
.gloss-theme-dark .gloss-update-tip-close:hover { background: #21262d; color: #fff; }
`,I="gloss-occurrence",H="gloss-highlight-style",ce=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT","CODE"]),O=500;function B(){const e=globalThis.CSS;return!e||!e.highlights||typeof globalThis.Highlight!="function"?null:e.highlights}function ae(){if(document.getElementById(H))return;const e=document.createElement("style");e.id=H,e.textContent=`::highlight(${I}) { background-color: rgba(255, 222, 89, 0.45); border-radius: 2px; }`,document.head.appendChild(e)}function de(e){const t=B();if(!t)return 0;ae(),G();const o=e.toLowerCase();if(o.length<2)return 0;const n=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(i){const s=i.parentElement;return!s||ce.has(s.tagName)||s.isContentEditable?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),r=[];let l;for(;l=n.nextNode();){const i=l.textContent??"";if(!i)continue;const s=i.toLowerCase();let u=0;for(;(u=s.indexOf(o,u))>=0;){const p=document.createRange();if(p.setStart(l,u),p.setEnd(l,u+o.length),r.push(p),u+=o.length,r.length>=O)break}if(r.length>=O)break}if(r.length===0)return 0;const a=globalThis.Highlight;return t.set(I,new a(...r)),r.length}function G(){const e=B();e&&e.delete(I)}const E=1e3;function ue(e,t){const n=t.toLowerCase().indexOf(e.toLowerCase());if(n<0)return t.slice(0,E*2);const r=Math.max(0,n-E),l=Math.min(t.length,n+e.length+E);return t.slice(r,l)}const C="gloss-host",ge="gloss-icon",pe="lookup-stream",c=window.__gloss??(window.__gloss={tooltipShown:!1,inited:!1,prefetch:null,activeTerm:null,activeInfo:null,tipPos:null,theme:"auto",updateInfo:null});function he(){let e=document.getElementById(C);if(e)return e.shadowRoot;e=document.createElement("div"),e.id=C,e.style.cssText="position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",document.documentElement.appendChild(e);const t=e.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=le,t.appendChild(o);const n=document.createElement("div");return n.id="gloss-root",t.appendChild(n),t}function x(){return he().getElementById("gloss-root")}function h(){c.tooltipShown=!1,c.activeTerm=null,c.activeInfo=null,c.tipPos=null,G();const e=x();for(S(null,e);e.firstChild;)e.removeChild(e.firstChild)}const v=380,b=8,f=8;function fe(e){const t=window.innerWidth,o=window.innerHeight;let n=e.left;n+v+f>t&&(n=Math.max(f,t-v-f));const r=o-e.bottom-b-f,l=e.top-b-f,a=r<200&&l>r,i=a?e.top-b:e.bottom+b;return{left:n,top:i,flipUp:a}}function me(e){if(c.theme==="light"||c.theme==="dark")return c.theme;let t=e;for(;t;){const n=window.getComputedStyle(t).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);if(n&&(n[4]!==void 0?Number(n[4]):1)>=.5){const l=Number(n[1]),a=Number(n[2]),i=Number(n[3]);return .299*l+.587*a+.114*i<128?"dark":"light"}t=t.parentElement}return typeof window.matchMedia=="function"&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function be(){var t;const e=["article","main",".markdown-body",'[role="main"]',"#content"];for(const o of e){const n=document.querySelector(o),r=n==null?void 0:n.innerText;if(r&&r.length>200)return r.slice(0,1e5)}return(((t=document.body)==null?void 0:t.innerText)??"").slice(0,1e5)}function W(e,t){const o={term:e,text:"",done:!1,result:null,listeners:new Set},n=()=>{for(const i of o.listeners)try{i()}catch(s){_.warn("listener 异常",s)}},r=i=>{o.done||(o.done=!0,o.result={kind:"error",term:e,code:"UNKNOWN",message:i},n())};let l;try{l=chrome.runtime.connect({name:pe})}catch(i){return r(i instanceof Error?i.message:String(i)),o}l.onMessage.addListener(i=>{i.type==="chunk"?(o.text+=i.text,n()):(o.done=!0,o.result=i.result,i.result.kind==="ai"&&!o.text&&(o.text=i.result.text),n())}),l.onDisconnect.addListener(()=>{var i;o.done||r(((i=chrome.runtime.lastError)==null?void 0:i.message)??"Port 断开")});const a={type:"lookup",term:e,pageText:ue(e,be()),pageUrl:location.href,bypassCache:t==null?void 0:t.bypassCache};try{l.postMessage(a)}catch(i){r(i instanceof Error?i.message:String(i))}return o}function Y(e){var t;return((t=c.prefetch)==null?void 0:t.term)===e||(c.prefetch=W(e)),c.prefetch}function we(e){const t=x(),o=e.rect.right+4,n=e.rect.top-4,r=F(e.term),l=r.ok?g("selectionClickToQuery"):r.reason;S(y("div",{id:ge,class:"gloss-icon",title:l,style:`position:absolute;left:${o}px;top:${n}px;`,onMouseEnter:()=>{r.ok&&Y(e.term)},onClick:()=>J(e)},"G"),t)}function xe(e){Q(e).catch(()=>{}),c.updateInfo=null}function w(e,t){var u;c.tooltipShown=!0,c.activeTerm=e.term,c.tipPos||(c.tipPos=fe(e.rect));const{left:o,top:n,flipUp:r}=c.tipPos,l=x(),a=r?"transform:translateY(-100%);":"",i=t.kind==="loading"?void 0:ke,s=me(((u=c.activeInfo)==null?void 0:u.anchorEl)??null)==="dark"?"gloss-theme-dark":"gloss-theme-light";S(y("div",{class:s,style:`position:absolute;left:${o}px;top:${n}px;${a}width:max-content;max-width:${v}px;`},y(re,{state:t,onClose:h,onRetry:i,updateInfo:c.updateInfo,onDismissUpdate:xe})),l)}function j(e,t){c.activeInfo=e;let o=!0;const n=()=>{!o&&(!c.tooltipShown||c.activeTerm!==e.term)||(o=!1,t.done&&t.result?w(e,{kind:"result",result:t.result}):t.text?w(e,{kind:"result",result:{kind:"ai",term:e.term,text:t.text,basedOn:[location.href]}}):w(e,{kind:"loading",term:e.term}))};t.listeners.add(n),n()}function J(e){const t=F(e.term);if(!t.ok){c.activeInfo=e,w(e,{kind:"result",result:{kind:"error",code:"TERM_REJECTED",term:e.term,message:t.reason}});return}const o=Y(e.term);j(e,o);try{de(e.term)}catch(n){_.warn("highlight 失败",n)}}function ke(){const e=c.activeInfo;if(!e)return;c.prefetch&&(c.prefetch.listeners.clear(),c.prefetch=null);const t=W(e.term,{bypassCache:!0});c.prefetch=t,j(e,t)}function Ee(){var s;const e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return;const t=e.toString(),o=D(t);if(!U(o))return;const n=e.getRangeAt(0),r=n.getBoundingClientRect(),l=n.commonAncestorContainer,a=l.nodeType===Node.ELEMENT_NODE?l:l.parentElement,i={term:o,rect:{top:r.top,left:r.left,bottom:r.bottom,right:r.right},anchorEl:a};c.activeTerm!==o&&(c.tipPos=null,((s=c.prefetch)==null?void 0:s.term)!==o&&(c.prefetch=null)),J(i)}function ye(e){if(history.pushState.__gloss)return;let t=location.href;const o=()=>{location.href!==t&&(t=location.href,e())};window.addEventListener("popstate",o);const n=history.pushState.bind(history),r=history.replaceState.bind(history),l=function(...i){n(...i),o()},a=function(...i){r(...i),o()};l.__gloss=!0,a.__gloss=!0,history.pushState=l,history.replaceState=a}function Te(){var n,r,l,a,i;if(c.inited)return;c.inited=!0,K().then(s=>{c.theme=s.theme,L(s.language)}).catch(()=>{});const e=((l=(r=(n=chrome.runtime)==null?void 0:n.getManifest)==null?void 0:r.call(n))==null?void 0:l.version)??"0.0.0";N(e).then(s=>{c.updateInfo=s}).catch(()=>{}),(i=(a=chrome.storage)==null?void 0:a.onChanged)==null||i.addListener((s,u)=>{if(u==="local"){if(s.settings){const p=s.settings.newValue;p!=null&&p.theme&&(c.theme=p.theme),p!=null&&p.language&&L(p.language)}s[V]&&N(e).then(p=>{c.updateInfo=p}).catch(()=>{})}}),ee(s=>{if(!c.tooltipShown){if(!s){h();return}c.prefetch&&c.prefetch.term!==s.term&&(c.prefetch=null),we(s)}}),document.addEventListener("keydown",s=>{s.key==="Escape"&&h()}),document.addEventListener("mousedown",s=>{const u=document.getElementById(C);u&&!u.contains(s.target)&&h()},{capture:!0});const t=300;let o=null;window.addEventListener("scroll",s=>{if(!x().firstChild){o=null;return}if(!(s.target===document||s.target===document.documentElement)){h(),o=null;return}o===null&&(o=window.scrollY),Math.abs(window.scrollY-o)>t&&(h(),o=null)},{capture:!0,passive:!0}),ye(()=>{_.debug("URL changed, unmount tooltip",location.href),h()}),chrome.runtime.onMessage.addListener(s=>{(s==null?void 0:s.type)==="trigger-lookup"&&Ee()})}Te();
