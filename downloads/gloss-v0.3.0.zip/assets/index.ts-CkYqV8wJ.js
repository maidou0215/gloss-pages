import{u as d,d as Q,R as L,k as T}from"./hooks.module-DJQNu05E.js";import{t as p,g as Z,s as M,b as P,S as ee,l as R,d as te}from"./i18n-BzlMVET0.js";import{_ as oe}from"./preload-helper-D7HrI6pR.js";function z(e){let t=e.trim();return t=t.replace(/^[\s "'()[\]{}「」『』“”‘’`]+/,""),t=t.replace(/[\s "'()[\]{}「」『』“”‘’`.,;:!?。，；：！？]+$/,""),t}function B(e){if(!e)return!1;const t=e.trim();return!(t.length===0||t.length>200||/[\n\r]/.test(e))}const A=30,ne=/[。？！.?!]/;function G(e){return e.length>A?{ok:!1,reason:p("selectionTooLong",[String(e.length),String(A)])}:ne.test(e)?{ok:!1,reason:p("selectionSentence")}:{ok:!0}}function re(e){let t=null,o=!1;function n(){const s=window.getSelection();if(!s||s.isCollapsed||s.rangeCount===0){e(null);return}const u=s.toString(),f=z(u);if(!B(f)){e(null);return}const g=s.getRangeAt(0),b=g.getBoundingClientRect(),k=g.commonAncestorContainer,K=k.nodeType===Node.ELEMENT_NODE?k:k.parentElement;e({term:f,rect:{top:b.top,left:b.left,bottom:b.bottom,right:b.right},anchorEl:K})}function r(s){t&&window.clearTimeout(t),t=window.setTimeout(()=>{o||n()},s)}function l(){o=!0,t&&(window.clearTimeout(t),t=null)}function a(){o=!1,r(80)}function i(){if(o){const s=window.getSelection();(!s||s.isCollapsed)&&e(null);return}r(300)}return document.addEventListener("mousedown",l),document.addEventListener("mouseup",a),document.addEventListener("selectionchange",i),()=>{document.removeEventListener("mousedown",l),document.removeEventListener("mouseup",a),document.removeEventListener("selectionchange",i),t&&window.clearTimeout(t)}}const se={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"};function ie(e){return e.replace(/[&<>"']/g,t=>se[t])}const $="",H="";function O(e){const t=[];return e=e.replace(/`([^`\n]+)`/g,(o,n)=>{const r=t.push(`<code>${n}</code>`)-1;return`${$}${r}${H}`}),e=e.replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>"),e=e.replace(/\[([^\]\n]+)\]\(((?:https?|mailto):[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'),e=e.replace(/(^|[\s>(])\*([^\s*][^*\n]*?)\*(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(/(^|[\s>(])_([^\s_][^_\n]*?)_(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(new RegExp(`${$}(\\d+)${H}`,"g"),(o,n)=>t[Number(n)]??""),e}function le(e){if(!e)return"";const o=ie(e).split(`
`),n=[];let r=[];const l=()=>{r.length!==0&&(n.push({kind:"p",lines:r}),r=[])};for(const i of o){const s=i.match(/^\s*[-*+]\s+(.+)$/)||i.match(/^\s*\d+\.\s+(.+)$/);if(s){l();const u=n[n.length-1];(u==null?void 0:u.kind)==="ul"?u.items.push(s[1]):n.push({kind:"ul",items:[s[1]]})}else i.trim()===""?l():r.push(i)}l();const a=[];for(const i of n)if(i.kind==="ul"){a.push("<ul>");for(const s of i.items)a.push(`<li>${O(s)}</li>`);a.push("</ul>")}else a.push(`<p>${i.lines.map(O).join("<br>")}</p>`);return a.join("")}function ce({state:e,onClose:t,onRetry:o,updateInfo:n,onDismissUpdate:r}){if(e.kind==="loading")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:e.term}),d("div",{class:"gloss-loading",children:[p("tooltipLoading"),d("span",{class:"gloss-dots"})]}),d(C,{info:n,onDismiss:r})]});const l=e.result;if(l.kind==="ai")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-ai",children:"AI"}),l.term,o&&d(Y,{onRetry:o})]}),d("div",{class:"gloss-md",dangerouslySetInnerHTML:{__html:le(l.text)}}),d("div",{class:"gloss-src",children:[p("tooltipBasedOn"),l.basedOn.join(", ")]}),d(C,{info:n,onDismiss:r})]});const a=l.code==="TERM_REJECTED"?void 0:o;return d(de,{err:l,onRetry:a,updateInfo:n,onDismissUpdate:r})}function C({info:e,onDismiss:t}){const[o,n]=Q(!1);return!e||o?null:d("div",{class:"gloss-update-tip",children:[d("a",{class:"gloss-update-tip-link",href:e.url,target:"_blank",rel:"noopener noreferrer",title:e.notes?p("tooltipUpdateTitleWithNotes",[e.latest,e.notes]):p("tooltipUpdateTitleOnly",e.latest),onMouseDown:r=>r.stopPropagation(),onClick:r=>r.stopPropagation(),children:[d("span",{class:"gloss-update-tip-dot",children:"●"}),p("tooltipUpdateAvailable",e.latest)]}),d("button",{class:"gloss-update-tip-close",title:p("tooltipDismissUpdateTitle"),onMouseDown:r=>r.stopPropagation(),onClick:r=>{r.stopPropagation(),n(!0),t==null||t(e.latest)},children:"✕"})]})}function Y({onRetry:e}){return d("button",{class:"gloss-retry",title:p("tooltipRetryTitle"),onClick:t=>{t.stopPropagation(),e()},onMouseDown:t=>t.stopPropagation(),children:"⟳"})}function ae(e){switch(e.code){case"AI_NOT_CONFIGURED":return{title:p("errorNotConfiguredTitle"),body:e.message,hint:p("errorNotConfiguredHint")};case"RATE_LIMITED":{const t=e.resetEpochSec?Math.max(0,e.resetEpochSec-Math.floor(Date.now()/1e3)):null;return{title:p("errorRateLimitedTitle"),body:e.message,hint:t?p("errorRateLimitedHintSeconds",String(t)):p("errorRateLimitedHintRetry")}}case"AI_FAILED":return{title:p("errorAiFailedTitle"),body:e.message,hint:p("errorAiFailedHint")};case"TERM_REJECTED":return{title:p("errorTermRejectedTitle"),body:e.message,hint:p("errorTermRejectedHint")};case"UNKNOWN":default:return{title:p("errorUnknownTitle"),body:e.message}}}function de({err:e,onRetry:t,updateInfo:o,onDismissUpdate:n}){const r=ae(e);return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-error",children:p("tooltipErrorTag")}),e.term,t&&d(Y,{onRetry:t})]}),d("div",{class:"gloss-err-title",children:r.title}),d("div",{class:"gloss-err-body",children:r.body}),r.hint&&d("div",{class:"gloss-hint",children:r.hint}),d(C,{info:o,onDismiss:n})]})}const ue=`
.gloss-tooltip {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: #ffffff; color: #1f2328; border: 1px solid #d0d7de;
  border-radius: 6px;
  padding: 10px 12px; font-size: 12px; line-height: 1.5;
  box-shadow: 0 6px 18px rgba(0,0,0,0.10);
  max-width: 380px;
  max-height: 60vh; overflow: auto;
  word-break: break-word; overflow-wrap: anywhere;
}
.gloss-icon {
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  width: 18px; height: 18px; border-radius: 9px;
  /* 跟工具栏图标主色 #2CC778 对齐（scripts/build-icon-16.py 取自 icon-48.png 主导绿） */
  background: #2CC778; color: #fff; font-size: 11px;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  user-select: none;
}
.gloss-header {
  font-weight: 700; margin-bottom: 6px; color: #1f2328;
  display: flex; align-items: center; gap: 4px;
}
.gloss-retry {
  margin-left: auto;
  background: transparent; border: none; cursor: pointer;
  color: #656d76; font-size: 14px; line-height: 1;
  padding: 2px 6px; border-radius: 4px;
  user-select: none;
}
.gloss-retry:hover { background: #f0f3f6; color: #1f2328; }
.gloss-retry:active { transform: rotate(180deg); transition: transform 0.3s; }
.gloss-tag {
  display: inline-block; padding: 1px 6px; border-radius: 3px;
  font-size: 10px; margin-right: 6px; font-weight: 600;
  vertical-align: middle; color: #fff;
  /* gloss-header 是 flex 容器，长 term 会触发收缩——
     tag 不加 flex-shrink:0 + white-space:nowrap 会让"错误"两字被压成竖排（一个字一行） */
  flex-shrink: 0;
  white-space: nowrap;
}
.gloss-tag-ai { background: #fb8500; }
.gloss-tag-error { background: #d73a49; }

/* Markdown 渲染样式 */
.gloss-md { font-size: 12px; }
.gloss-md p { margin: 0 0 6px 0; }
.gloss-md p:last-child { margin-bottom: 0; }
.gloss-md ul { margin: 4px 0; padding-left: 18px; }
.gloss-md li { margin: 2px 0; }
.gloss-md code {
  background: #f6f8fa; color: #cf222e; padding: 1px 4px;
  border-radius: 3px; font-family: ui-monospace, monospace;
  font-size: 11px;
}
.gloss-md strong { font-weight: 700; color: #1f2328; }
.gloss-md em { font-style: italic; color: #1f2328; }
.gloss-md a { color: #0969da; text-decoration: none; }
.gloss-md a:hover { text-decoration: underline; }

/* 加载/错误态 */
.gloss-loading { color: #656d76; }
.gloss-dots::after {
  content: '...'; display: inline-block;
  animation: gloss-dots 1.2s infinite steps(4);
  width: 1.2em; text-align: left;
}
@keyframes gloss-dots {
  0%, 25% { content: ''; }
  50%     { content: '.'; }
  75%     { content: '..'; }
  100%    { content: '...'; }
}
.gloss-err-title { color: #cf222e; font-weight: 600; margin-bottom: 4px; }
.gloss-err-body { color: #656d76; font-size: 11px; margin-bottom: 6px; }
.gloss-hint {
  color: #656d76; font-size: 11px;
  border-top: 1px solid #d0d7de; padding-top: 6px; margin-top: 4px;
}

.gloss-src {
  color: #656d76; font-size: 10px; margin-top: 8px;
  padding-top: 6px; border-top: 1px solid #d0d7de;
}
.gloss-src a { color: #0969da; text-decoration: none; }

/* 更新 tip：底部小字，可有可无；左边是跳转链接，右边是 ✕ 关闭 */
.gloss-update-tip {
  display: flex; align-items: center; gap: 4px;
  margin-top: 6px; padding-top: 6px;
  border-top: 1px dashed #d0d7de;
  font-size: 10px;
}
.gloss-update-tip-link {
  flex: 1;
  display: inline-flex; align-items: center; gap: 5px;
  color: #656d76; text-decoration: none;
  transition: color 0.12s;
}
.gloss-update-tip-link:hover { color: #0969da; }
.gloss-update-tip-dot {
  color: #2da44e; font-size: 6px; line-height: 1;
}
.gloss-update-tip-close {
  background: transparent; border: none; cursor: pointer;
  color: #8b949e; font-size: 11px; line-height: 1;
  padding: 1px 5px; border-radius: 3px;
  transition: background 0.12s, color 0.12s;
}
.gloss-update-tip-close:hover { background: #f0f3f6; color: #1f2328; }

/* 暗色：跟随【当前页面】背景亮度判定（content/index.ts detectPageTheme），
   不再用 prefers-color-scheme——系统 dark mode 下白底页面会被误判 */
.gloss-theme-dark .gloss-tooltip {
  background: #1a1a1a; color: #fff; border-color: #30363d;
  box-shadow: 0 6px 18px rgba(0,0,0,0.40);
}
.gloss-theme-dark .gloss-header { color: #fff; }
.gloss-theme-dark .gloss-md code { background: #21262d; color: #d2a8ff; }
.gloss-theme-dark .gloss-md strong { color: #fff; }
.gloss-theme-dark .gloss-md em { color: #c9d1d9; }
.gloss-theme-dark .gloss-md a { color: #79c0ff; }
.gloss-theme-dark .gloss-loading { color: #c9d1d9; }
.gloss-theme-dark .gloss-err-title { color: #ffb4ab; }
.gloss-theme-dark .gloss-err-body { color: #c9d1d9; }
.gloss-theme-dark .gloss-hint { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src a { color: #79c0ff; }
.gloss-theme-dark .gloss-retry { color: #8b949e; }
.gloss-theme-dark .gloss-retry:hover { background: #21262d; color: #fff; }
.gloss-theme-dark .gloss-update-tip { border-top-color: #30363d; }
.gloss-theme-dark .gloss-update-tip-link { color: #8b949e; }
.gloss-theme-dark .gloss-update-tip-link:hover { color: #79c0ff; }
.gloss-theme-dark .gloss-update-tip-dot { color: #56d364; }
.gloss-theme-dark .gloss-update-tip-close { color: #6e7681; }
.gloss-theme-dark .gloss-update-tip-close:hover { background: #21262d; color: #fff; }
`,N="gloss-occurrence",D="gloss-highlight-style",pe=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT","CODE"]),F=500;function j(){const e=globalThis.CSS;return!e||!e.highlights||typeof globalThis.Highlight!="function"?null:e.highlights}function ge(){if(document.getElementById(D))return;const e=document.createElement("style");e.id=D,e.textContent=`::highlight(${N}) { background-color: rgba(255, 222, 89, 0.45); border-radius: 2px; }`,document.head.appendChild(e)}function fe(e){const t=j();if(!t)return 0;ge(),W();const o=e.toLowerCase();if(o.length<2)return 0;const n=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(i){const s=i.parentElement;return!s||pe.has(s.tagName)||s.isContentEditable?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),r=[];let l;for(;l=n.nextNode();){const i=l.textContent??"";if(!i)continue;const s=i.toLowerCase();let u=0;for(;(u=s.indexOf(o,u))>=0;){const f=document.createRange();if(f.setStart(l,u),f.setEnd(l,u+o.length),r.push(f),u+=o.length,r.length>=F)break}if(r.length>=F)break}if(r.length===0)return 0;const a=globalThis.Highlight;return t.set(N,new a(...r)),r.length}function W(){const e=j();e&&e.delete(N)}const S="gloss-force-select",he="* { -webkit-user-select: text !important; user-select: text !important; }";function v(){if(document.getElementById(S))return;const e=document.createElement("style");e.id=S,e.textContent=he,document.documentElement.appendChild(e)}function U(){var e;(e=document.getElementById(S))==null||e.remove()}async function me(){const{isForceSelectEnabled:e}=await oe(async()=>{const{isForceSelectEnabled:t}=await import("./force-select-store-DpP_qy4x.js");return{isForceSelectEnabled:t}},[]);await e(location.hostname)&&v()}const y=1e3;function be(e,t){const n=t.toLowerCase().indexOf(e.toLowerCase());if(n<0)return t.slice(0,y*2);const r=Math.max(0,n-y),l=Math.min(t.length,n+e.length+y);return t.slice(r,l)}const _="gloss-host",we="gloss-icon",xe="lookup-stream",c=window.__gloss??(window.__gloss={tooltipShown:!1,inited:!1,prefetch:null,activeTerm:null,activeInfo:null,tipPos:null,theme:"auto",updateInfo:null});function Ee(){let e=document.getElementById(_);if(e)return e.shadowRoot;e=document.createElement("div"),e.id=_,e.style.cssText="position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",document.documentElement.appendChild(e);const t=e.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=ue,t.appendChild(o);const n=document.createElement("div");return n.id="gloss-root",t.appendChild(n),t}function E(){return Ee().getElementById("gloss-root")}function h(){c.tooltipShown=!1,c.activeTerm=null,c.activeInfo=null,c.tipPos=null,W();const e=E();for(L(null,e);e.firstChild;)e.removeChild(e.firstChild)}const I=380,w=8,m=8;function ke(e){const t=window.innerWidth,o=window.innerHeight;let n=e.left;n+I+m>t&&(n=Math.max(m,t-I-m));const r=o-e.bottom-w-m,l=e.top-w-m,a=r<200&&l>r,i=a?e.top-w:e.bottom+w;return{left:n,top:i,flipUp:a}}function ye(e){if(c.theme==="light"||c.theme==="dark")return c.theme;let t=e;for(;t;){const n=window.getComputedStyle(t).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);if(n&&(n[4]!==void 0?Number(n[4]):1)>=.5){const l=Number(n[1]),a=Number(n[2]),i=Number(n[3]);return .299*l+.587*a+.114*i<128?"dark":"light"}t=t.parentElement}return typeof window.matchMedia=="function"&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function Te(){var t;const e=["article","main",".markdown-body",'[role="main"]',"#content"];for(const o of e){const n=document.querySelector(o),r=n==null?void 0:n.innerText;if(r&&r.length>200)return r.slice(0,1e5)}return(((t=document.body)==null?void 0:t.innerText)??"").slice(0,1e5)}function J(e,t){const o={term:e,text:"",done:!1,result:null,listeners:new Set},n=()=>{for(const i of o.listeners)try{i()}catch(s){R.warn("listener 异常",s)}},r=i=>{o.done||(o.done=!0,o.result={kind:"error",term:e,code:"UNKNOWN",message:i},n())};let l;try{l=chrome.runtime.connect({name:xe})}catch(i){return r(i instanceof Error?i.message:String(i)),o}l.onMessage.addListener(i=>{i.type==="chunk"?(o.text+=i.text,n()):(o.done=!0,o.result=i.result,i.result.kind==="ai"&&!o.text&&(o.text=i.result.text),n())}),l.onDisconnect.addListener(()=>{var i;o.done||r(((i=chrome.runtime.lastError)==null?void 0:i.message)??"Port 断开")});const a={type:"lookup",term:e,pageText:be(e,Te()),pageUrl:location.href,bypassCache:t==null?void 0:t.bypassCache};try{l.postMessage(a)}catch(i){r(i instanceof Error?i.message:String(i))}return o}function V(e){var t;return((t=c.prefetch)==null?void 0:t.term)===e||(c.prefetch=J(e)),c.prefetch}function Ce(e){const t=E(),o=e.rect.right+4,n=e.rect.top-4,r=G(e.term),l=r.ok?p("selectionClickToQuery"):r.reason;L(T("div",{id:we,class:"gloss-icon",title:l,style:`position:absolute;left:${o}px;top:${n}px;`,onMouseEnter:()=>{r.ok&&V(e.term)},onClick:()=>q(e)},"G"),t)}function Se(e){te(e).catch(()=>{}),c.updateInfo=null}function x(e,t){var u;c.tooltipShown=!0,c.activeTerm=e.term,c.tipPos||(c.tipPos=ke(e.rect));const{left:o,top:n,flipUp:r}=c.tipPos,l=E(),a=r?"transform:translateY(-100%);":"",i=t.kind==="loading"?void 0:ve,s=ye(((u=c.activeInfo)==null?void 0:u.anchorEl)??null)==="dark"?"gloss-theme-dark":"gloss-theme-light";L(T("div",{class:s,style:`position:absolute;left:${o}px;top:${n}px;${a}width:max-content;max-width:${I}px;`},T(ce,{state:t,onClose:h,onRetry:i,updateInfo:c.updateInfo,onDismissUpdate:Se})),l)}function X(e,t){c.activeInfo=e;let o=!0;const n=()=>{!o&&(!c.tooltipShown||c.activeTerm!==e.term)||(o=!1,t.done&&t.result?x(e,{kind:"result",result:t.result}):t.text?x(e,{kind:"result",result:{kind:"ai",term:e.term,text:t.text,basedOn:[location.href]}}):x(e,{kind:"loading",term:e.term}))};t.listeners.add(n),n()}function q(e){const t=G(e.term);if(!t.ok){c.activeInfo=e,x(e,{kind:"result",result:{kind:"error",code:"TERM_REJECTED",term:e.term,message:t.reason}});return}const o=V(e.term);X(e,o);try{fe(e.term)}catch(n){R.warn("highlight 失败",n)}}function ve(){const e=c.activeInfo;if(!e)return;c.prefetch&&(c.prefetch.listeners.clear(),c.prefetch=null);const t=J(e.term,{bypassCache:!0});c.prefetch=t,X(e,t)}function _e(){var s;const e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return;const t=e.toString(),o=z(t);if(!B(o))return;const n=e.getRangeAt(0),r=n.getBoundingClientRect(),l=n.commonAncestorContainer,a=l.nodeType===Node.ELEMENT_NODE?l:l.parentElement,i={term:o,rect:{top:r.top,left:r.left,bottom:r.bottom,right:r.right},anchorEl:a};c.activeTerm!==o&&(c.tipPos=null,((s=c.prefetch)==null?void 0:s.term)!==o&&(c.prefetch=null)),q(i)}function Ie(e){if(history.pushState.__gloss)return;let t=location.href;const o=()=>{location.href!==t&&(t=location.href,e())};window.addEventListener("popstate",o);const n=history.pushState.bind(history),r=history.replaceState.bind(history),l=function(...i){n(...i),o()},a=function(...i){r(...i),o()};l.__gloss=!0,a.__gloss=!0,history.pushState=l,history.replaceState=a}function Le(){var n,r,l,a,i;if(c.inited)return;c.inited=!0,Z().then(s=>{c.theme=s.theme,M(s.language)}).catch(()=>{});const e=((l=(r=(n=chrome.runtime)==null?void 0:n.getManifest)==null?void 0:r.call(n))==null?void 0:l.version)??"0.0.0";P(e).then(s=>{c.updateInfo=s}).catch(()=>{}),(i=(a=chrome.storage)==null?void 0:a.onChanged)==null||i.addListener((s,u)=>{var f;if(u==="local"){if(s.settings){const g=s.settings.newValue;g!=null&&g.theme&&(c.theme=g.theme),g!=null&&g.language&&M(g.language)}if(s[ee]&&P(e).then(g=>{c.updateInfo=g}).catch(()=>{}),s.forceSelectHosts){const g=s.forceSelectHosts.newValue;(f=g==null?void 0:g.enabled)!=null&&f.includes(location.hostname)?v():U()}}}),re(s=>{if(!c.tooltipShown){if(!s){h();return}c.prefetch&&c.prefetch.term!==s.term&&(c.prefetch=null),Ce(s)}}),document.addEventListener("keydown",s=>{s.key==="Escape"&&h()}),document.addEventListener("mousedown",s=>{const u=document.getElementById(_);u&&!u.contains(s.target)&&h()},{capture:!0});const t=300;let o=null;window.addEventListener("scroll",s=>{if(!E().firstChild){o=null;return}if(!(s.target===document||s.target===document.documentElement)){h(),o=null;return}o===null&&(o=window.scrollY),Math.abs(window.scrollY-o)>t&&(h(),o=null)},{capture:!0,passive:!0}),Ie(()=>{R.debug("URL changed, unmount tooltip",location.href),h()}),me().catch(()=>{}),chrome.runtime.onMessage.addListener(s=>{(s==null?void 0:s.type)==="trigger-lookup"&&_e(),(s==null?void 0:s.type)==="force-select-enable"&&v(),(s==null?void 0:s.type)==="force-select-disable"&&U()})}Le();
