import{u as d,i as K,R as v,k as y}from"./disabled-hosts-store-DPNc-udD.js";import{t as u,g as Z,s as N,l as I}from"./i18n-Dkoaznuc.js";import{_ as ee}from"./preload-helper-D7HrI6pR.js";function te(e){const t=e.replace(/[^a-zA-Z]/g,"");return t.length>0&&t.length/e.length>.5}function oe(e){return e.trim().split(/\s+/).filter(Boolean).length}function B(e){let t=e.trim();return t=t.replace(/^[\s "'()[\]{}「」『』“”‘’`]+/,""),t=t.replace(/[\s "'()[\]{}「」『』“”‘’`.,;:!?。，；：！？]+$/,""),t}function z(e){if(!e)return!1;const t=e.trim();return!(t.length===0||t.length>200||/[\n\r]/.test(e))}const M=30,P=5,ne=/[。？！.?!]/;function G(e){if(te(e)){const t=oe(e);if(t>P)return{ok:!1,reason:u("selectionTooLongEn",[String(t),String(P)])}}else if(e.length>M)return{ok:!1,reason:u("selectionTooLongZh",[String(e.length),String(M)])};return ne.test(e)?{ok:!1,reason:u("selectionSentence")}:{ok:!0}}function re(e){let t=null,n=!1;function r(){const i=window.getSelection();if(!i||i.isCollapsed||i.rangeCount===0){e(null);return}const f=i.toString(),h=B(f);if(!z(h)){e(null);return}const R=i.getRangeAt(0),m=R.getBoundingClientRect(),x=R.commonAncestorContainer,Q=x.nodeType===Node.ELEMENT_NODE?x:x.parentElement;e({term:h,rect:{top:m.top,left:m.left,bottom:m.bottom,right:m.right},anchorEl:Q})}function o(i){t&&window.clearTimeout(t),t=window.setTimeout(()=>{n||r()},i)}function c(){n=!0,t&&(window.clearTimeout(t),t=null)}function a(){n=!1,o(80)}function s(){if(n){const i=window.getSelection();(!i||i.isCollapsed)&&e(null);return}o(300)}return document.addEventListener("mousedown",c,!0),document.addEventListener("mouseup",a,!0),document.addEventListener("selectionchange",s),()=>{document.removeEventListener("mousedown",c,!0),document.removeEventListener("mouseup",a,!0),document.removeEventListener("selectionchange",s),t&&window.clearTimeout(t)}}const se={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"};function ie(e){return e.replace(/[&<>"']/g,t=>se[t])}const A="",$="";function H(e){const t=[];return e=e.replace(/`([^`\n]+)`/g,(n,r)=>{const o=t.push(`<code>${r}</code>`)-1;return`${A}${o}${$}`}),e=e.replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>"),e=e.replace(/\[([^\]\n]+)\]\(((?:https?|mailto):[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'),e=e.replace(/(^|[\s>(])\*([^\s*][^*\n]*?)\*(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(/(^|[\s>(])_([^\s_][^_\n]*?)_(?=[\s<).,;:!?]|$)/g,"$1<em>$2</em>"),e=e.replace(new RegExp(`${A}(\\d+)${$}`,"g"),(n,r)=>t[Number(r)]??""),e}function le(e){if(!e)return"";const n=ie(e).split(`
`),r=[];let o=[];const c=()=>{o.length!==0&&(r.push({kind:"p",lines:o}),o=[])};for(const s of n){const i=s.match(/^\s*[-*+]\s+(.+)$/)||s.match(/^\s*\d+\.\s+(.+)$/);if(i){c();const f=r[r.length-1];(f==null?void 0:f.kind)==="ul"?f.items.push(i[1]):r.push({kind:"ul",items:[i[1]]})}else s.trim()===""?c():o.push(s)}c();const a=[];for(const s of r)if(s.kind==="ul"){a.push("<ul>");for(const i of s.items)a.push(`<li>${H(i)}</li>`);a.push("</ul>")}else a.push(`<p>${s.lines.map(H).join("<br>")}</p>`);return a.join("")}function ce({state:e,onClose:t,onRetry:n}){if(e.kind==="loading")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:e.term}),d("div",{class:"gloss-loading",children:[u("tooltipLoading"),d("span",{class:"gloss-dots"})]})]});const r=e.result;if(r.kind==="ai")return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-ai",children:"AI"}),r.term,n&&d(Y,{onRetry:n})]}),d("div",{class:"gloss-md",dangerouslySetInnerHTML:{__html:le(r.text)}}),d("div",{class:"gloss-src",children:[u("tooltipBasedOn"),r.basedOn.join(", ")]})]});const o=r.code==="TERM_REJECTED"?void 0:n;return d(de,{err:r,onRetry:o})}function Y({onRetry:e}){return d("button",{class:"gloss-retry",title:u("tooltipRetryTitle"),onClick:t=>{t.stopPropagation(),e()},onMouseDown:t=>t.stopPropagation(),children:"⟳"})}function ae(e){switch(e.code){case"AI_NOT_CONFIGURED":return{title:u("errorNotConfiguredTitle"),body:e.message,hint:u("errorNotConfiguredHint")};case"RATE_LIMITED":{const t=e.resetEpochSec?Math.max(0,e.resetEpochSec-Math.floor(Date.now()/1e3)):null;return{title:u("errorRateLimitedTitle"),body:e.message,hint:t?u("errorRateLimitedHintSeconds",String(t)):u("errorRateLimitedHintRetry")}}case"AI_FAILED":return{title:u("errorAiFailedTitle"),body:e.message,hint:u("errorAiFailedHint")};case"TERM_REJECTED":return{title:u("errorTermRejectedTitle"),body:e.message,hint:u("errorTermRejectedHint")};case"UNKNOWN":default:return{title:u("errorUnknownTitle"),body:e.message}}}function de({err:e,onRetry:t}){const n=ae(e);return d("div",{class:"gloss-tooltip",children:[d("div",{class:"gloss-header",children:[d("span",{class:"gloss-tag gloss-tag-error",children:u("tooltipErrorTag")}),e.term,t&&d(Y,{onRetry:t})]}),d("div",{class:"gloss-err-title",children:n.title}),d("div",{class:"gloss-err-body",children:n.body}),n.hint&&d("div",{class:"gloss-hint",children:n.hint})]})}const ue=`
.gloss-tooltip {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: #ffffff; color: #1f2328; border: 1px solid #d0d7de;
  border-radius: 6px;
  padding: 10px 12px; font-size: 12px; line-height: 1.5;
  box-shadow: 0 6px 18px rgba(0,0,0,0.10);
  max-width: 380px;
  max-height: 60vh; overflow: auto;
  word-break: break-word; overflow-wrap: anywhere;
}
.gloss-icon {
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  width: 18px; height: 18px; border-radius: 9px;
  /* 跟工具栏图标主色 #2CC778 对齐（scripts/build-icon-16.py 取自 icon-48.png 主导绿） */
  background: #2CC778; color: #fff; font-size: 11px;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  user-select: none;
}
.gloss-header {
  font-weight: 700; margin-bottom: 6px; color: #1f2328;
  display: flex; align-items: center; gap: 4px;
}
.gloss-retry {
  margin-left: auto;
  background: transparent; border: none; cursor: pointer;
  color: #656d76; font-size: 14px; line-height: 1;
  padding: 2px 6px; border-radius: 4px;
  user-select: none;
}
.gloss-retry:hover { background: #f0f3f6; color: #1f2328; }
.gloss-retry:active { transform: rotate(180deg); transition: transform 0.3s; }
.gloss-tag {
  display: inline-block; padding: 1px 6px; border-radius: 3px;
  font-size: 10px; margin-right: 6px; font-weight: 600;
  vertical-align: middle; color: #fff;
  /* gloss-header 是 flex 容器，长 term 会触发收缩——
     tag 不加 flex-shrink:0 + white-space:nowrap 会让"错误"两字被压成竖排（一个字一行） */
  flex-shrink: 0;
  white-space: nowrap;
}
.gloss-tag-ai { background: #fb8500; }
.gloss-tag-error { background: #d73a49; }

/* Markdown 渲染样式 */
.gloss-md { font-size: 12px; }
.gloss-md p { margin: 0 0 6px 0; }
.gloss-md p:last-child { margin-bottom: 0; }
.gloss-md ul { margin: 4px 0; padding-left: 18px; }
.gloss-md li { margin: 2px 0; }
.gloss-md code {
  background: #f6f8fa; color: #cf222e; padding: 1px 4px;
  border-radius: 3px; font-family: ui-monospace, monospace;
  font-size: 11px;
}
.gloss-md strong { font-weight: 700; color: #1f2328; }
.gloss-md em { font-style: italic; color: #1f2328; }
.gloss-md a { color: #0969da; text-decoration: none; }
.gloss-md a:hover { text-decoration: underline; }

/* 加载/错误态 */
.gloss-loading { color: #656d76; }
.gloss-dots::after {
  content: '...'; display: inline-block;
  animation: gloss-dots 1.2s infinite steps(4);
  width: 1.2em; text-align: left;
}
@keyframes gloss-dots {
  0%, 25% { content: ''; }
  50%     { content: '.'; }
  75%     { content: '..'; }
  100%    { content: '...'; }
}
.gloss-err-title { color: #cf222e; font-weight: 600; margin-bottom: 4px; }
.gloss-err-body { color: #656d76; font-size: 11px; margin-bottom: 6px; }
.gloss-hint {
  color: #656d76; font-size: 11px;
  border-top: 1px solid #d0d7de; padding-top: 6px; margin-top: 4px;
}

.gloss-src {
  color: #656d76; font-size: 10px; margin-top: 8px;
  padding-top: 6px; border-top: 1px solid #d0d7de;
}
.gloss-src a { color: #0969da; text-decoration: none; }

/* 暗色：跟随【当前页面】背景亮度判定（content/index.ts detectPageTheme），
   不再用 prefers-color-scheme——系统 dark mode 下白底页面会被误判 */
.gloss-theme-dark .gloss-tooltip {
  background: #1a1a1a; color: #fff; border-color: #30363d;
  box-shadow: 0 6px 18px rgba(0,0,0,0.40);
}
.gloss-theme-dark .gloss-header { color: #fff; }
.gloss-theme-dark .gloss-md code { background: #21262d; color: #d2a8ff; }
.gloss-theme-dark .gloss-md strong { color: #fff; }
.gloss-theme-dark .gloss-md em { color: #c9d1d9; }
.gloss-theme-dark .gloss-md a { color: #79c0ff; }
.gloss-theme-dark .gloss-loading { color: #c9d1d9; }
.gloss-theme-dark .gloss-err-title { color: #ffb4ab; }
.gloss-theme-dark .gloss-err-body { color: #c9d1d9; }
.gloss-theme-dark .gloss-hint { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src { color: #8b949e; border-top-color: #30363d; }
.gloss-theme-dark .gloss-src a { color: #79c0ff; }
.gloss-theme-dark .gloss-retry { color: #8b949e; }
.gloss-theme-dark .gloss-retry:hover { background: #21262d; color: #fff; }
`,L="gloss-occurrence",D="gloss-highlight-style",fe=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT","CODE"]),F=500;function j(){const e=globalThis.CSS;return!e||!e.highlights||typeof globalThis.Highlight!="function"?null:e.highlights}function ge(){if(document.getElementById(D))return;const e=document.createElement("style");e.id=D,e.textContent=`::highlight(${L}) { background-color: rgba(255, 222, 89, 0.45); border-radius: 2px; }`,document.head.appendChild(e)}function he(e){const t=j();if(!t)return 0;ge(),J();const n=e.toLowerCase();if(n.length<2)return 0;const r=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(s){const i=s.parentElement;return!i||fe.has(i.tagName)||i.isContentEditable?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),o=[];let c;for(;c=r.nextNode();){const s=c.textContent??"";if(!s)continue;const i=s.toLowerCase();let f=0;for(;(f=i.indexOf(n,f))>=0;){const h=document.createRange();if(h.setStart(c,f),h.setEnd(c,f+n.length),o.push(h),f+=n.length,o.length>=F)break}if(o.length>=F)break}if(o.length===0)return 0;const a=globalThis.Highlight;return t.set(L,new a(...o)),o.length}function J(){const e=j();e&&e.delete(L)}const T="gloss-force-select",O="gloss-force-select-script",pe="* { -webkit-user-select: text !important; user-select: text !important; }",me=`
(function() {
  var e = document.getElementById('${O}');
  if (e) return;
  ['selectstart','copy','contextmenu','dragstart'].forEach(function(t) {
    document.addEventListener(t, function(e) { e.stopPropagation(); }, true);
  });
  var s = document.createElement('script');
  s.id = '${O}';
  document.documentElement.appendChild(s);
})();`;function C(){if(document.getElementById(T))return;const e=document.createElement("style");e.id=T,e.textContent=pe,document.documentElement.appendChild(e);const t=document.createElement("script");t.textContent=me,document.documentElement.appendChild(t),t.remove()}function U(){var e;(e=document.getElementById(T))==null||e.remove()}async function Ee(){const{isForceSelectEnabled:e}=await ee(async()=>{const{isForceSelectEnabled:t}=await import("./force-select-store-DpP_qy4x.js");return{isForceSelectEnabled:t}},[]);await e(location.hostname)&&C()}const k=1e3;function we(e,t){const r=t.toLowerCase().indexOf(e.toLowerCase());if(r<0)return t.slice(0,k*2);const o=Math.max(0,r-k),c=Math.min(t.length,r+e.length+k);return t.slice(o,c)}const S="gloss-host",be="gloss-icon",xe="lookup-stream",l=window.__gloss??(window.__gloss={tooltipShown:!1,inited:!1,prefetch:null,activeTerm:null,activeInfo:null,tipPos:null,theme:"auto",blocked:!1});function ke(){let e=document.getElementById(S);if(e)return e.shadowRoot;e=document.createElement("div"),e.id=S,e.style.cssText="position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;",document.documentElement.appendChild(e);const t=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=ue,t.appendChild(n);const r=document.createElement("div");return r.id="gloss-root",t.appendChild(r),t}function b(){return ke().getElementById("gloss-root")}function g(){l.tooltipShown=!1,l.activeTerm=null,l.activeInfo=null,l.tipPos=null,J();const e=b();for(v(null,e);e.firstChild;)e.removeChild(e.firstChild)}const _=380,E=8,p=8;function ye(e){const t=window.innerWidth,n=window.innerHeight;let r=e.left;r+_+p>t&&(r=Math.max(p,t-_-p));const o=n-e.bottom-E-p,c=e.top-E-p,a=o<200&&c>o,s=a?e.top-E:e.bottom+E;return{left:r,top:s,flipUp:a}}function Te(e){if(l.theme==="light"||l.theme==="dark")return l.theme;let t=e;for(;t;){const r=window.getComputedStyle(t).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);if(r&&(r[4]!==void 0?Number(r[4]):1)>=.5){const c=Number(r[1]),a=Number(r[2]),s=Number(r[3]);return .299*c+.587*a+.114*s<128?"dark":"light"}t=t.parentElement}return typeof window.matchMedia=="function"&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function Ce(){var t;const e=["article","main",".markdown-body",'[role="main"]',"#content"];for(const n of e){const r=document.querySelector(n),o=r==null?void 0:r.innerText;if(o&&o.length>200)return o.slice(0,1e5)}return(((t=document.body)==null?void 0:t.innerText)??"").slice(0,1e5)}function X(e,t){const n={term:e,text:"",done:!1,result:null,listeners:new Set},r=()=>{for(const s of n.listeners)try{s()}catch(i){I.warn("listener 异常",i)}},o=s=>{n.done||(n.done=!0,n.result={kind:"error",term:e,code:"UNKNOWN",message:s},r())};let c;try{c=chrome.runtime.connect({name:xe})}catch(s){return o(s instanceof Error?s.message:String(s)),n}c.onMessage.addListener(s=>{s.type==="chunk"?(n.text+=s.text,r()):(n.done=!0,n.result=s.result,s.result.kind==="ai"&&!n.text&&(n.text=s.result.text),r())}),c.onDisconnect.addListener(()=>{var s;n.done||o(((s=chrome.runtime.lastError)==null?void 0:s.message)??"Port 断开")});const a={type:"lookup",term:e,pageText:we(e,Ce()),pageUrl:location.href,bypassCache:t==null?void 0:t.bypassCache};try{c.postMessage(a)}catch(s){o(s instanceof Error?s.message:String(s))}return n}function V(e){var t;return((t=l.prefetch)==null?void 0:t.term)===e||(l.prefetch=X(e)),l.prefetch}function Se(e){const t=b(),n=(e.rect.left+e.rect.right)/2-9,r=e.rect.bottom+4,o=G(e.term),c=o.ok?u("selectionClickToQuery"):o.reason;v(y("div",{id:be,class:"gloss-icon",title:c,style:`position:absolute;left:${n}px;top:${r}px;`,onMouseEnter:()=>{o.ok&&V(e.term)},onClick:()=>q(e)},"G"),t)}function w(e,t){var f;l.tooltipShown=!0,l.activeTerm=e.term,l.tipPos||(l.tipPos=ye(e.rect));const{left:n,top:r,flipUp:o}=l.tipPos,c=b(),a=o?"transform:translateY(-100%);":"",s=t.kind==="loading"?void 0:_e,i=Te(((f=l.activeInfo)==null?void 0:f.anchorEl)??null)==="dark"?"gloss-theme-dark":"gloss-theme-light";v(y("div",{class:i,style:`position:absolute;left:${n}px;top:${r}px;${a}width:max-content;max-width:${_}px;`},y(ce,{state:t,onClose:g,onRetry:s})),c)}function W(e,t){l.activeInfo=e;let n=!0;const r=()=>{!n&&(!l.tooltipShown||l.activeTerm!==e.term)||(n=!1,t.done&&t.result?w(e,{kind:"result",result:t.result}):t.text?w(e,{kind:"result",result:{kind:"ai",term:e.term,text:t.text,basedOn:[location.href]}}):w(e,{kind:"loading",term:e.term}))};t.listeners.add(r),r()}function q(e){const t=G(e.term);if(!t.ok){l.activeInfo=e,w(e,{kind:"result",result:{kind:"error",code:"TERM_REJECTED",term:e.term,message:t.reason}});return}const n=V(e.term);W(e,n);try{he(e.term)}catch(r){I.warn("highlight 失败",r)}}function _e(){const e=l.activeInfo;if(!e)return;l.prefetch&&(l.prefetch.listeners.clear(),l.prefetch=null);const t=X(e.term,{bypassCache:!0});l.prefetch=t,W(e,t)}function ve(){var i;const e=window.getSelection();if(!e||e.isCollapsed||e.rangeCount===0)return;const t=e.toString(),n=B(t);if(!z(n))return;const r=e.getRangeAt(0),o=r.getBoundingClientRect(),c=r.commonAncestorContainer,a=c.nodeType===Node.ELEMENT_NODE?c:c.parentElement,s={term:n,rect:{top:o.top,left:o.left,bottom:o.bottom,right:o.right},anchorEl:a};l.activeTerm!==n&&(l.tipPos=null,((i=l.prefetch)==null?void 0:i.term)!==n&&(l.prefetch=null)),q(s)}function Ie(e){if(history.pushState.__gloss)return;let t=location.href;const n=()=>{location.href!==t&&(t=location.href,e())};window.addEventListener("popstate",n);const r=history.pushState.bind(history),o=history.replaceState.bind(history),c=function(...s){r(...s),n()},a=function(...s){o(...s),n()};c.__gloss=!0,a.__gloss=!0,history.pushState=c,history.replaceState=a}function Le(){var n,r;if(Z().then(o=>{l.theme=o.theme,N(o.language)}).catch(()=>{}),l.inited)return;l.inited=!0,K(location.hostname).then(o=>{o&&(l.blocked=!0,g())}).catch(()=>{}),(r=(n=chrome.storage)==null?void 0:n.onChanged)==null||r.addListener((o,c)=>{var a,s;if(c==="local"){if(o.settings){const i=o.settings.newValue;i!=null&&i.theme&&(l.theme=i.theme),i!=null&&i.language&&N(i.language)}if(o.forceSelectHosts){const i=o.forceSelectHosts.newValue;(a=i==null?void 0:i.enabled)!=null&&a.includes(location.hostname)?C():U()}if(o.disabledHosts){const i=o.disabledHosts.newValue;l.blocked=((s=i==null?void 0:i.hosts)==null?void 0:s.includes(location.hostname))??!1,l.blocked&&g()}}}),re(o=>{if(!l.blocked&&!l.tooltipShown){if(!o){g();return}l.prefetch&&l.prefetch.term!==o.term&&(l.prefetch=null),Se(o)}}),document.addEventListener("keydown",o=>{o.key==="Escape"&&g()}),document.addEventListener("mousedown",o=>{const c=document.getElementById(S);c&&!c.contains(o.target)&&g()},{capture:!0});const e=300;let t=null;window.addEventListener("scroll",o=>{if(!b().firstChild){t=null;return}if(!(o.target===document||o.target===document.documentElement)){g(),t=null;return}t===null&&(t=window.scrollY),Math.abs(window.scrollY-t)>e&&(g(),t=null)},{capture:!0,passive:!0}),Ie(()=>{I.debug("URL changed, unmount tooltip",location.href),g()}),Ee().catch(()=>{}),chrome.runtime.onMessage.addListener(o=>{(o==null?void 0:o.type)==="trigger-lookup"&&ve(),(o==null?void 0:o.type)==="force-select-enable"&&C(),(o==null?void 0:o.type)==="force-select-disable"&&U()})}Le();
